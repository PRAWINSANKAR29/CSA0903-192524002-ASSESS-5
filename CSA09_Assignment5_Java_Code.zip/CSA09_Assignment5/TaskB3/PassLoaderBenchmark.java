import java.sql.*;
import java.util.*;

public class PassLoaderBenchmark {
    static String url() { return System.getenv().getOrDefault("DB_URL","jdbc:mysql://localhost:3306/csa09_test"); }
    static String user() { return System.getenv().getOrDefault("DB_USER","root"); }
    static String pass() { return System.getenv().getOrDefault("DB_PASSWORD",""); }

    static List<String[]> generate(int n) {
        List<String[]> rows = new ArrayList<>(n);
        for (int i=1;i<=n;i++) rows.add(new String[]{"P"+i,"REG"+i,"Student"+i,
                Integer.toString((i%20)+1), "4500.0"});
        return rows;
    }
    static void clear(Connection c) throws SQLException {
        try (Statement s=c.createStatement()) { s.executeUpdate("DELETE FROM bus_pass"); }
    }
    static long batch(Connection c, List<String[]> rows) throws SQLException {
        long t=System.nanoTime(); PassLoader.loadAll(c, rows); return System.nanoTime()-t;
    }
    public static void main(String[] args) {
        try (Connection c=DriverManager.getConnection(url(),user(),pass())) {
            for (int n : new int[]{1000,10000,100000}) {
                clear(c); long ns=batch(c,generate(n));
                System.out.printf("Batch transaction n=%d : %.2f ms%n",n,ns/1e6);
            }
            DatabaseMetaData md=c.getMetaData();
            System.out.println("Database: "+md.getDatabaseProductName());
            System.out.println("Driver: "+md.getDriverName()+" "+md.getDriverVersion());
            try (ResultSet rs=md.getColumns(null,null,"bus_pass",null)) {
                while(rs.next()) System.out.println(rs.getString("COLUMN_NAME")+" : "+rs.getString("TYPE_NAME"));
            }
        } catch (SQLException e) {
            System.out.println("MySQL setup required: "+e.getMessage());
            System.out.println("Run sql/assignment5.sql, add Connector/J, then rerun.");
        }
    }
}
