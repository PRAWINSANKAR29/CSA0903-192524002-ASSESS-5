import java.io.*;
import java.nio.file.*;

public class BufferedLineCounter {
    static long countUnbuffered(Path p) throws IOException {
        long lines = 0;
        try (InputStream in = new FileInputStream(p.toFile())) {
            int b; while ((b = in.read()) != -1) if (b == '\n') lines++;
        }
        return lines;
    }
    static long countBuffered(Path p) throws IOException {
        long lines = 0;
        try (InputStream in = new BufferedInputStream(Files.newInputStream(p), 64 * 1024)) {
            byte[] buf = new byte[64 * 1024]; int n;
            while ((n = in.read(buf)) != -1)
                for (int i = 0; i < n; i++) if (buf[i] == '\n') lines++;
        }
        return lines;
    }
    public static void main(String[] args) throws Exception {
        Path p = Files.createTempFile("attendance", ".log");
        String row = "192311001,Present,2026-11-15\n";
        try (BufferedWriter w = Files.newBufferedWriter(p)) {
            for (int i=0; i<100000; i++) w.write(row);
        }
        long a = System.nanoTime(); long x = countUnbuffered(p); long b = System.nanoTime();
        long y0 = System.nanoTime(); long y = countBuffered(p); long c = System.nanoTime();
        System.out.println("Lines (unbuffered): " + x);
        System.out.println("Lines (buffered):   " + y);
        System.out.printf("Unbuffered time: %.3f ms%n", (b-a)/1e6);
        System.out.printf("Buffered time:   %.3f ms%n", (c-y0)/1e6);
        Files.deleteIfExists(p);
    }
}
