import java.io.*;
import java.nio.file.*;
import java.util.*;

public class PassStore {
    private final Path file;
    public PassStore(Path file) { this.file = file; }

    public void add(String passId, String regNo, String name, int route, double amount)
            throws IOException {
        // CSV-safe encoding: quote fields containing comma, quote or newline.
        String[] fields = {passId, regNo, name, Integer.toString(route), Double.toString(amount)};
        try (BufferedWriter w = Files.newBufferedWriter(file, StandardOpenOption.CREATE,
                StandardOpenOption.APPEND)) {
            w.write(String.join(",", Arrays.stream(fields).map(PassStore::csv).toList()));
            w.newLine();
        }
    }

    private static String csv(String s) {
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        }
        return s;
    }

    // Small CSV parser supporting quoted commas and escaped quotes.
    static String[] parse(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (ch == '"') {
                if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    field.append('"'); i++;
                } else quoted = !quoted;
            } else if (ch == ',' && !quoted) {
                out.add(field.toString()); field.setLength(0);
            } else field.append(ch);
        }
        if (quoted) throw new IllegalArgumentException("Unclosed quoted field");
        out.add(field.toString());
        return out.toArray(String[]::new);
    }

    public String[] find(String passId) throws IOException {
        try (BufferedReader r = Files.newBufferedReader(file)) {
            String line;
            while ((line = r.readLine()) != null) {
                try {
                    String[] p = parse(line);
                    if (p.length != 5) continue;
                    Integer.parseInt(p[3]);
                    Double.parseDouble(p[4]);
                    if (p[0].equals(passId)) return p;
                } catch (RuntimeException damaged) {
                    System.err.println("Skipping damaged line: " + line);
                }
            }
        }
        return null;
    }

    public List<String[]> listByRoute(int route) throws IOException {
        List<String[]> result = new ArrayList<>();
        try (BufferedReader r = Files.newBufferedReader(file)) {
            String line;
            while ((line = r.readLine()) != null) {
                try {
                    String[] p = parse(line);
                    if (p.length == 5 && Integer.parseInt(p[3]) == route
                            && Double.parseDouble(p[4]) >= 0) result.add(p);
                } catch (RuntimeException damaged) {
                    System.err.println("Skipping damaged line: " + line);
                }
            }
        }
        return result;
    }

    public static void main(String[] args) throws Exception {
        Path f = Files.createTempFile("passes", ".csv");
        PassStore store = new PassStore(f);
        store.add("P1001", "192311001", "Arun", 12, 4500);
        Files.writeString(f, "P1002,DAMAGED LINE\n", StandardOpenOption.APPEND);
        store.add("P1003", "192311003", "Divya", 7, 3800);
        System.out.println(Arrays.toString(store.find("P1003")));
        System.out.println(Arrays.toString(store.find("P1002")));
        System.out.println("Route 7 count: " + store.listByRoute(7).size());
        Files.deleteIfExists(f);
    }
}
