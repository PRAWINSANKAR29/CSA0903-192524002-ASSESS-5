# Assignment 5 – Part A: Persistence Design & Pseudocode Notes

> Adapt the pseudocode to the SIMATS Engineering Standard for Algorithmic Pseudocode required by the course. These are model design notes; personalize them and verify against your faculty's exact notation.

## A1 – Design a File Format

**Delimited text record:** `pass_id,reg_no,name,route_no,boarding_stop,validity_date,amount_paid`. Use UTF-8 CSV with quoted fields and doubled embedded quotes (`"Main, East"`; `"A ""quoted"" name"`). Never split blindly on commas; use a CSV parser. Include a schema/version header if the format will evolve.

**Binary record:** write fields in a documented fixed order using `DataOutputStream`: `writeUTF(passId)`, `writeUTF(regNo)`, `writeUTF(name)`, `writeInt(routeNo)`, `writeUTF(boardingStop)`, `writeLong(validityDate.toEpochDay())`, `writeDouble(amountPaid)`. Length-prefixed UTF fields avoid fixed-width padding; record offsets are not constant, so scan or maintain an index.

**Operations (text):**
- ADD: validate fields; append one complete CSV row through `BufferedWriter(Files.newBufferedWriter(..., CREATE, APPEND))`; flush/close; for stronger durability write to a temporary file and atomically replace, or use a journal.
- FIND: use `BufferedReader(Files.newBufferedReader(...))`; parse each row; validate field count/types; return matching pass ID; log/skip malformed rows.
- LIST BY ROUTE: scan with `BufferedReader`; parse and validate each row; emit rows whose route matches.
- Missing file: create it for ADD; for FIND/LIST report empty/not found or a clear IOException depending on API contract.
- Damaged line: reject/record line number and continue; do not silently reinterpret malformed fields.
- Interrupted write: append can leave a partial final line; detect missing newline/invalid field count/checksum. For stronger recovery, write complete temp file then atomic move, or append a journal record with checksum and recover only complete records.

**Alternative – RandomAccessFile:** fixed-size records permit `seek(i * recordSize)` in O(1) when record index is known. Finding by ID without an index remains O(n) scan. Fixed-size strings require padding and truncate/reject long values; space waste is the sum of unused field capacity. A separate ID-to-offset index enables expected O(1) lookup but needs consistency/rebuild logic.

## A2 – Buffering

A 50 MiB file read one byte at a time makes about 52,428,800 Java `read()` calls. A direct FileInputStream byte read can cause very frequent native/OS interactions and call overhead. A 64 KiB byte buffer reduces read calls to about 800 (plus final partial read); scan bytes in memory for `\\n`. Buffering helps sequential reads, not when data is already in memory, the file is tiny, or the bottleneck is CPU/network/processing rather than I/O.

`Files.readAllLines()` is O(file size) time and O(file size + object overhead) memory; buffered streaming is O(file size) time and O(buffer size) working memory. Prefer streaming for 50 MB or larger/unbounded logs; read-all-lines for small files that comfortably fit in memory and need repeated random access.

## A3 – DAO Pattern

Repeated steps: obtain connection, prepare/execute SQL, map ResultSet rows to objects, handle exceptions, close resources. Differences: entity/table names, columns, SQL and row-to-object mapping. Define `Dao<T,K>` with `insert(T)`, `findById(K)`, `findAll()`, `update(T)`, `delete(K)`. `StudentDao` implements it and owns SQL plus mapping. Example mapping: `Student.id` → `student_id` primary key; `name` → `student_name`; `regNo` → `register_no`; `email` → `email`. A DAO centralizes schema changes; SQL in GUI/service code spreads changes across many places. Runtime/space per query are essentially the same asymptotically; DAO adds negligible dispatch/object overhead and improves maintainability.

## A4 – Serialization

Mark the live `Connection` field `transient` because it is a runtime resource, not persistent state; re-create it after deserialization. Mark password `transient` too, and preferably do not store plaintext credentials at all. The Hostel → Rooms → Residents object graph is traversed; every reachable non-transient object must be serializable or `NotSerializableException` occurs. Use a stable `serialVersionUID`. Adding a phone field with the same UID generally deserializes old streams with the new field default (`null` for String); validate/migrate it. A changed UID normally causes `InvalidClassException`. CSV/JSON is human-readable and language-neutral but needs explicit mapping/escaping; serialization can be compact/easy for Java object graphs but is tightly coupled to class versions and can be unsafe for untrusted input. Both save/load n residents in O(n) time; sizes depend on representation and object metadata.

## A5 – Transactions and Injection

Transfer ₹500 in one JDBC transaction: `setAutoCommit(false)`; debit source only if balance ≥ 500; credit destination; commit; on any SQLException/runtime failure rollback; restore original auto-commit in finally. This gives atomicity. Two auto-commit statements can debit without credit (or credit without debit), violating conservation; separate statements may have lower transaction-management overhead but correctness risk is unacceptable.

Unsafe concatenation allows input such as `' OR '1'='1' -- ` to alter SQL logic. Use `SELECT ... WHERE id=? AND pwd=?`, bind both values with `PreparedStatement.setString`; user data remains data, not SQL syntax. Escaping or regex validation is weaker because it is easy to miss encodings/DB-specific syntax and does not reliably separate code from data. PreparedStatement parsing/planning may be reused and is the robust standard.
