import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.*;

public class PassFileMigrator {
    static String url=System.getenv().getOrDefault("DB_URL","jdbc:mysql://localhost:3306/csa09_test");
    static String user=System.getenv().getOrDefault("DB_USER","root");
    static String pass=System.getenv().getOrDefault("DB_PASSWORD","");
    public static void main(String[] args) {
        Path file=Path.of(args.length>0?args[0]:"data/bus_passes.csv");
        List<String[]> valid=new ArrayList<>(); List<String> rejected=new ArrayList<>();
        try (BufferedReader r=Files.newBufferedReader(file)) {
            String line; int lineNo=0;
            while((line=r.readLine())!=null) {
                lineNo++;
                try {
                    String[] p=PassStoreCompat.parse(line);
                    if(p.length!=5 || p[0].isBlank() || p[1].isBlank()
                            || Integer.parseInt(p[3])<=0 || Double.parseDouble(p[4])<0)
                        throw new IllegalArgumentException("invalid fields");
                    valid.add(p);
                } catch(Exception ex) { rejected.add("Line "+lineNo+": "+line+" ("+ex.getMessage()+")"); }
            }
        } catch(IOException e) { System.out.println("File error: "+e.getMessage()); return; }
        try(Connection c=DriverManager.getConnection(url,user,pass)) {
            int loaded=PassLoaderCompat.loadAll(c,valid);
            System.out.println("Valid records: "+valid.size());
            System.out.println("Loaded records: "+loaded);
            System.out.println("Rejected records: "+rejected.size());
            rejected.forEach(System.out::println);
            DatabaseMetaData md=c.getMetaData();
            System.out.println("Database: "+md.getDatabaseProductName());
            System.out.println("Driver: "+md.getDriverVersion());
            try(ResultSet rs=md.getTables(null,null,"%",new String[]{"TABLE"})) {
                while(rs.next()) System.out.println("Table: "+rs.getString("TABLE_NAME"));
            }
        } catch(SQLException e) { System.out.println("Migration needs configured MySQL: "+e.getMessage()); }
    }
}
class PassStoreCompat {
    static String[] parse(String line) {
        // This migration input uses simple comma-delimited fields.
        return line.split(",",-1);
    }
}
class PassLoaderCompat {
    static int loadAll(Connection c,List<String[]> rows) throws SQLException {
        String q="INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)";
        boolean old=c.getAutoCommit(); c.setAutoCommit(false);
        try(PreparedStatement p=c.prepareStatement(q)) {
            int n=0;
            for(String[] r:rows) {
                p.setString(1,r[0]); p.setString(2,r[1]); p.setString(3,r[2]);
                p.setInt(4,Integer.parseInt(r[3])); p.setDouble(5,Double.parseDouble(r[4]));
                p.addBatch(); n++;
                if(n%1000==0) p.executeBatch();
            }
            p.executeBatch(); c.commit(); return n;
        } catch(SQLException|RuntimeException e) { c.rollback(); throw e; }
        finally { c.setAutoCommit(old); }
    }
}
