# CSA09 – Programming in Java – Assignment 5 (CO5)

Java 21 starter implementation for Part B (B1–B4), based on the supplied assignment PDF.

## Requirements
- JDK 17+ (tested with Java 21)
- MySQL 8+ for B2, B3 and B4
- MySQL Connector/J JAR for JDBC tasks

## Compile
From this folder:
```bash
javac TaskB1/*.java
javac TaskB2/SqlInjectionDemo.java
javac TaskB3/*.java
javac TaskB4/*.java
```
For JDBC tasks include Connector/J in the classpath, for example:
```bash
javac -cp .;mysql-connector-j-9.x.x.jar TaskB2/SqlInjectionDemo.java
java  -cp .;mysql-connector-j-9.x.x.jar TaskB2.SqlInjectionDemo
```
(If running on Windows PowerShell, use `;` as the classpath separator. On macOS/Linux use `:`.)

Set environment variables:
- `DB_URL=jdbc:mysql://localhost:3306/csa09_test`
- `DB_USER=root`
- `DB_PASSWORD=your_password`

Run `sql/assignment5.sql` in MySQL Workbench before B2/B3/B4.

## Tasks included
- B1: CSV pass store with damaged-line skipping, route listing, and unbuffered/buffered line counter.
- B2: Unsafe Statement login vs safe PreparedStatement using a local test database.
- B3: JDBC batch loader in batches of 1,000, transaction rollback, benchmark and metadata.
- B4: File-to-database migration with validation failure report and DatabaseMetaData inspection.

## Important academic notes
This package implements Part B code foundations and the two supplied TODO programs. The assignment also requires Part A written record layouts, SIMATS-standard pseudocode, DAO design, serialization analysis, transaction/injection reasoning, measured experiments, and interpretation. Add your own measured results (1 MB, 10 MB, 50 MB; 1k, 10k, 100k rows) from your laptop. JDBC results cannot be honestly claimed until MySQL and Connector/J are configured and the programs are run against your test database. GUI/laptop screenshots in the companion PDF are formatted evidence previews, not photographs of your physical laptop.
