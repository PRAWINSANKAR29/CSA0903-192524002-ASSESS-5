import java.sql.*;
import java.util.Scanner;

/*
 * Requires MySQL Connector/J and a local test database.
 * Set DB_URL, DB_USER and DB_PASSWORD environment variables before running.
 */
public class SqlInjectionDemo {
    static final String URL = System.getenv().getOrDefault("DB_URL",
            "jdbc:mysql://localhost:3306/csa09_test");
    static final String USER = System.getenv().getOrDefault("DB_USER", "root");
    static final String PASS = System.getenv().getOrDefault("DB_PASSWORD", "");

    static boolean unsafeLogin(Connection c, String id, String pwd) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE id='" + id + "' AND pwd='" + pwd + "'";
        try (Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            rs.next(); return rs.getInt(1) > 0;
        }
    }
    static boolean safeLogin(Connection c, String id, String pwd) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE id=? AND pwd=?";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id); ps.setString(2, pwd);
            try (ResultSet rs = ps.executeQuery()) { rs.next(); return rs.getInt(1) > 0; }
        }
    }
    public static void main(String[] args) {
        String attack = "' OR '1'='1' -- ";
        try (Connection c = DriverManager.getConnection(URL, USER, PASS)) {
            System.out.println("Unsafe accepts crafted input: " + unsafeLogin(c, "nobody", attack));
            System.out.println("PreparedStatement accepts crafted input: " + safeLogin(c, "nobody", attack));
        } catch (SQLException e) {
            System.out.println("Database connection required: " + e.getMessage());
            System.out.println("Configure MySQL and run sql/assignment5.sql first.");
        }
    }
}
