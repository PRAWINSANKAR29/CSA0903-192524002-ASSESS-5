CREATE DATABASE IF NOT EXISTS csa09_test;
USE csa09_test;

DROP TABLE IF EXISTS bus_pass;
CREATE TABLE bus_pass (
    pass_id VARCHAR(20) PRIMARY KEY,
    reg_no VARCHAR(20) NOT NULL,
    name VARCHAR(100) NOT NULL,
    route_no INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL
);

DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id VARCHAR(50) PRIMARY KEY,
    pwd VARCHAR(255) NOT NULL
);
INSERT INTO users(id,pwd) VALUES ('student1','pass123');
